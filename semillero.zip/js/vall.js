var correo = "unad.edu.co";
var correo2 = "unadvirtual.edu.co";

function validarEstudiante() {
    alert("Bienvenido estimado estudiante.");
    window.location.assign("estudiantes")
}

function validarDocente() {
    alert("Bienvenido estimado tutor.");
    window.location.assign("profesores/index.php")
}